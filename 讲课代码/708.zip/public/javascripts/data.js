foo({'username':'aoao'});

